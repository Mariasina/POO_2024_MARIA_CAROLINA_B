package Formativas.Heranca2.EX3;

public class Montanha extends Terreno{

    @Override
    public String describe(){
        return "Um terreno tortuoso, com picos altos.";
    }
}
