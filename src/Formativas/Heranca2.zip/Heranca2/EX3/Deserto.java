package Formativas.Heranca2.EX3;

public class Deserto extends Terreno{

    @Override
    public String describe(){
        return "Um terreno seco e arenoso, com muitas dunas.";
    }
}
