package Formativas.Heranca2.EX3;

public class Terreno {

    public String describe(){
        return "Um terreno plano com vegetação padrão.";
    }
}
