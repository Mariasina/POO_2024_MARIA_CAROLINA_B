package Formativas.Heranca2.EX3;

public class Floresta extends Terreno{

    @Override
    public String describe(){
        return "Um terreno com muitas árvores e arbustos.";
    }
}
